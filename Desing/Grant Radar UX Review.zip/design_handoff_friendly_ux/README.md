# Handoff: Friendly UX redesign — IIAL Grants

## Overview
A system-wide clarity redesign of IIAL Grants. Same product, same data, same
routes — but plain language, one obvious action per item, calmer layout, and a
single prominent "Do this next" recommendation on every work surface. The goal
is that a first-time user understands what to do without training.

## What's in this bundle
- **`V2GrantsWorkspace.tsx`** — **production, drop-in** replacement for
  `src/components/v2/V2GrantsWorkspace.tsx`. Same props contract, same imports
  (TanStack `Link`, shadcn `Button/Badge/Input/Select/Tabs`, `lucide-react`,
  your `GrantRowData` type, `SORT_LABELS`/`SortKey`, `cn`). It compiles against
  the current repo with no other changes. **This is real code, not a mock.**
- **`reference-prototype.html`** — the navigable HTML prototype showing the
  friendly design applied to all 18 screens. This is a **design reference**
  (built in HTML), the visual source of truth for the screens not yet ported to
  TSX. Recreate these in the app's existing React/TanStack/shadcn environment —
  do not ship the HTML.

## Fidelity
**High-fidelity.** Final colors, type, spacing, and copy. Recreate pixel-close
using the existing design system (Tailwind v4 tokens in `src/styles.css`,
shadcn components, `lucide-react`). The `[data-ui-version="v2"]` teal theme is
already applied by `V2AuthenticatedShell` — use semantic classes
(`bg-card`, `text-primary`, `text-muted-foreground`, `border`) so both themes work.

## How to apply the drop-in (Grant Radar)
1. Replace `src/components/v2/V2GrantsWorkspace.tsx` with the file in this bundle.
2. No route or prop changes — `_authenticated.grants.index.tsx` already passes
   every prop this component reads.
3. `bun run dev`, open `/grants` with the v2 UI toggle on. Verify: KPI strip,
   "Do this next" banner, List/Board/Needs-a-look tabs, and each row's action.

## Screens (friendly redesign)
All screens keep your `V2AuthenticatedShell` (navy sidebar, top bar). The nav
group labels were rewritten to plain words (implement in
`V2AuthenticatedShell.tsx` `NAV_GROUPS`): **Every day** (Home, Grant radar,
Funders), **Your applications** (Proposals, Quality check, Submissions),
**After you win** (Awards, Money, Impact, Renewals), **Stay on track** (Tasks,
Deadlines, Market view), **Set up** (About us, What we show you, Guide, Privacy).

For each screen, purpose → layout → key copy. See `reference-prototype.html`
for exact composition.

### Grant radar (`/grants`) — DONE in TSX
Compact header + actions ("What we show you", "Find new grants"); one 5-up KPI
strip (Grants in view / You can apply / Closing soon / Ready to draft / Need a
look); "Do this next" banner (top-priority grant, one CTA); search + sort
("Best matches first") + jurisdiction ("Anywhere") + "I can apply" / "Has a
deadline" toggles + List/Board/Needs-a-look switch; decision cards with a fit
ring, friendly match label, plain eligibility chip, "Closes in N days", and one
verb button ("Draft application" / "Check the fit" / "Get the details" / "Take a
closer look").

### Home (`/dashboard`)
Greeting ("Good afternoon, {name}"), the same "Do this next" banner, a 4-up
week-stats row (New grants found / Applications going / Deadlines this week /
Won this year), and two columns: "Deadlines coming up" (date chip + label +
days-left) and "Applications in progress" (title + status + progress bar).

### Grant detail (`/grants/:id`)
Back link; eligibility + deadline chips; title + funder + jurisdiction; a
**verdict card** — fit ring (score / 100 + "Good match") beside a plain verdict
("Yes — worth applying, but move fast.") and five friendly checks ("Can you
apply?", "Is the money worth it?", "Does it match you?", "Is there enough
time?", "Can you trust it?") each with a check/warn icon + one line; "The key
facts" grid (Deadline, Funding, Who can apply, What it funds); "What you'll need
to apply" checklist (Ready / To do / Optional); "Where this comes from" source
links; a navy "Ready to start?" CTA card.

### Proposals (`/proposals`)
Header + "New application"; per-proposal card: title + status pill (Almost
ready / In progress / Just started / Sent), funder · deadline, progress bar +
"N of M sections", a Quality column (letter grade + label), and a CTA
("Finish & review" / "Keep drafting" / "View").

### Quality check (`/quality`)
Navy summary card (overall grade + one-line note); per-proposal card: letter
grade tile + title + bulleted plain fixes ("Budget section feels thin — add
detail.") + "Open".

### Submissions (`/submissions`)
4-up summary (Sent / Won / Waiting / Win rate); per-submission card: title +
status pill (Won / Waiting / Not this time), funder · date, plain next step.

### Awards (`/post-award`)
3-up summary (Won this year / Active grants / Reports due); per-award row:
trophy tile, title, funder + next-report chip, amount awarded.

### Money (`/financial`)
4-up summary (Awarded / Spent so far / Still available / On budget?);
"Spending by grant" list with labeled progress bars ("Spent $150K of $220K").

### Impact (`/impact`)
2-up big-number cards (312 Youth trained — "Target was 250 — you beat it.", etc).

### Renewals (`/renewal`)
Per-item row: refresh tile, title, likelihood pill ("Very likely / Likely /
Possible to reopen"), plain note, "Remind me".

### Tasks (`/tasks`)
Grouped by Due today / This week / Later; each row: checkbox, title, context
line, assignee avatar + name.

### Deadlines (`/compliance-calendar`)
Grouped by This week / This month / Later; each row: date chip, title, type tag
(Application / Report), funder, days-left, "Open".

### Market view (`/competitive`)
3-up stat cards; "Recently funded, like you" list (org, funder · sector, amount).

### About us (`/org`)
Profile-completeness ring banner + "Finish profile"; field rows (type, where,
focus areas, project size, team size, charitable status) each with "Edit".

### What we show you (`/fit-rules`)
Three profile cards (Show me everything / Balanced [active] / Only the best);
plain rule list with on/off toggles + state label ("Only show grants I can
legally apply to", "Skip grants below $25,000", etc).

### Guide (`/manual`) & Privacy (`/privacy`)
Guide: 2-up topic cards. Privacy: 2-up point cards (local-first promises).

## Interactions & behavior
- Sidebar nav switches screens; active item highlighted (white pill on navy).
- "Do this next" CTA → grant detail. Row primary action fires the same handlers
  as today (`onEnrich` / `onEvaluate` / `onDraft`), only the labels changed.
- List / Board / Needs-a-look is the existing Queue / Lifecycle / Exceptions
  data behind friendlier labels.
- Toggles ("I can apply", "Has a deadline") map to `eligibleOnly` /
  `onlyWithDeadline`. Sort "Best matches first" = existing `fit` key.
- No behavior/removal of features — this is presentation + copy only.

## Design tokens (from `src/styles.css`, v2 theme)
- Primary (teal): `--primary` `oklch(0.43 0.115 188)` → `bg-primary`/`text-primary`
- Brand (amber): `--brand` `oklch(0.68 0.15 48)` → used on the "Do this next" icon/label
- Sidebar navy: `oklch(0.2 0.026 218)`
- Success emerald `#16a34a`, warning amber `#d97706`, danger rose `#e11d48` (or `text-emerald-600`/`amber-600`/`rose-600`)
- Surfaces: `bg-card`, `bg-background`, `border`, `text-foreground`, `text-muted-foreground`
- Radius: cards `rounded-xl`/`rounded-2xl`, controls `rounded-lg`; fit ring 60px, r=16, stroke 4
- Type: Work Sans (body + headings in v2), sizes 30/16/14/13/12/11px as in the prototype
- Icons: `lucide-react`, 14–18px, stroke 2

## Copy principles (apply everywhere)
Plain verbs and human phrasing: "You can apply" not "eligibility_pass"; "Closes
in 5 days" not a raw date; "Draft application" not "Draft"; "Great/Good match /
Worth a look / Not checked yet" for fit; "Need a look" not "Exceptions". Never
show internal status codes — map through friendly labels.

## Files
- `V2GrantsWorkspace.tsx` — drop-in TSX (this bundle)
- `reference-prototype.html` — full 18-screen visual reference
- Source screens to touch, by route: see the Screens section above.
